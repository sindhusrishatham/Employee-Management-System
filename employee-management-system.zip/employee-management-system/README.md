# Employee Management System

REST API built with Java 17, Spring Boot, Spring Data JPA, and an H2 database.
Supports CRUD operations, validation, search by name, and filtering by department.

## Run
    mvn spring-boot:run

API base URL: http://localhost:8080/api/employees
H2 console: http://localhost:8080/h2-console  (JDBC URL: jdbc:h2:mem:emsdb, user: sa)

## Endpoints
| Method | URL | Description |
|--------|-----|-------------|
| POST | /api/employees | Add employee |
| GET | /api/employees | List all |
| GET | /api/employees/{id} | Get one |
| PUT | /api/employees/{id} | Update |
| DELETE | /api/employees/{id} | Delete |
| GET | /api/employees/department/{dept} | Filter by department |
| GET | /api/employees/search?name=ra | Search by name |

## Sample request body
    {
      "name": "Ravi Kumar",
      "email": "ravi@example.com",
      "department": "IT",
      "designation": "Developer",
      "salary": 55000
    }
