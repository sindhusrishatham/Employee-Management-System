package com.sindhu.ems.repository;

import com.sindhu.ems.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByDepartmentIgnoreCase(String department);
    List<Employee> findByNameContainingIgnoreCase(String name);
}
